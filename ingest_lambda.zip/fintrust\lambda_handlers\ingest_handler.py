import csv
import io
import boto3

from fintrust.ingest import process_transaction

s3 = boto3.client("s3")


def lambda_handler(event, context):

    processed = 0
    failed = 0

    for record in event["Records"]:

        bucket = record["s3"]["bucket"]["name"]
        key = record["s3"]["object"]["key"]

        response = s3.get_object(
            Bucket=bucket,
            Key=key
        )

        csv_content = (
            response["Body"]
            .read()
            .decode("utf-8")
        )

        reader = csv.DictReader(
            io.StringIO(csv_content)
        )

        for row in reader:

            try:

                process_transaction(
                    account_id=int(row["account_id"]),
                    amount=float(row["amount"]),
                    transaction_type=row["transaction_type"],
                    country=row["country"]
                )

                processed += 1

            except Exception as error:

                print(
                    f"Failed row: {row}"
                )

                print(str(error))

                failed += 1

    return {
        "success": True,
        "processed": processed,
        "failed": failed
    }